function checkPalindrome() {
  const inputString = document.getElementById("inputString").value;
  const sanitizedInput = inputString.toLowerCase().replace(/[^a-z0-9]/g, '');
  const reversedString = sanitizedInput.split("").reverse().join("");
  if (sanitizedInput === reversedString) {
    document.getElementById("output").textContent = "Palindrome!";
  } else {
    document.getElementById("output").textContent = "Not a Palindrome";
  }
}