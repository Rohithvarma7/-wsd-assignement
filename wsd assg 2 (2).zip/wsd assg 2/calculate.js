function calculateTotal() {
  const subtotal = parseFloat(document.getElementById("subtotal").value);
  const tipPercentage = parseFloat(document.getElementById("tipPercentage").value);
  const tipAmount = (subtotal * tipPercentage) / 100;
  const totalAmount = subtotal + tipAmount;
  document.getElementById("output").textContent = "Total Amount: $" + totalAmount.toFixed(2);
}